import os
import time
import hashlib
import secrets
import psycopg2
import psycopg2.extras
from datetime import datetime
from functools import wraps
from flask import (
    Flask, render_template, request, redirect,
    url_for, session, flash, abort, Response
)

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", secrets.token_hex(32))

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
USERS_DIR = os.path.join(BASE_DIR, "data")

DB_CONFIG = {
    "host": os.environ.get("DB_HOST", "localhost"),
    "user": os.environ.get("DB_USER", "dnevnik"),
    "password": os.environ.get("DB_PASSWORD", "dnevnik"),
    "dbname": os.environ.get("DB_NAME", "dnevnik"),
}


def get_db():
    conn = psycopg2.connect(**DB_CONFIG)
    conn.autocommit = False
    return conn


def init_db():
    for attempt in range(30):
        try:
            conn = get_db()
            with conn.cursor() as cur:
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS users (
                        id SERIAL PRIMARY KEY,
                        username VARCHAR(255) NOT NULL UNIQUE,
                        password VARCHAR(255) NOT NULL,
                        full_name VARCHAR(255) NOT NULL,
                        email VARCHAR(255) NOT NULL,
                        created TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)
            conn.commit()
            conn.close()
            return
        except psycopg2.OperationalError:
            time.sleep(2)
    raise RuntimeError("Could not connect to PostgreSQL after 60 seconds")


init_db()

os.makedirs(USERS_DIR, exist_ok=True)

GRADES_HEADER = ["date", "subject", "exam", "score", "max_score", "homework"]

TEST_BANK = {
    "Математика": {
        "Экзамен": {
            "name": "Итоговый экзамен по математике",
            "time_minutes": 30,
            "questions": [
                {"q": "Чему равна производная x²?", "opts": ["2x", "x²", "2", "x"], "answer": 0},
                {"q": "Решите: 3x + 7 = 22", "opts": ["x = 3", "x = 5", "x = 7", "x = 4"], "answer": 1},
                {"q": "Чему равен √144?", "opts": ["14", "12", "11", "13"], "answer": 1},
                {"q": "Площадь круга с радиусом 3?", "opts": ["9π", "6π", "3π", "12π"], "answer": 0},
                {"q": "Чему равен log₁₀(1000)?", "opts": ["2", "4", "3", "10"], "answer": 2},
                {"q": "Упростите: (x³)²", "opts": ["x⁵", "x⁶", "x⁹", "x⁸"], "answer": 1},
                {"q": "Сумма внутренних углов шестиугольника?", "opts": ["540°", "720°", "900°", "360°"], "answer": 1},
                {"q": "Если f(x) = 3x − 2, чему равно f(4)?", "opts": ["10", "14", "12", "8"], "answer": 0},
            ],
        },
        "Тест": {
            "name": "Короткий тест по математике",
            "time_minutes": 10,
            "questions": [
                {"q": "15 × 12 = ?", "opts": ["170", "180", "160", "190"], "answer": 1},
                {"q": "Чему равно 25% от 200?", "opts": ["25", "75", "50", "100"], "answer": 2},
                {"q": "Упростите: 4/8", "opts": ["1/4", "1/2", "2/4", "3/4"], "answer": 1},
                {"q": "Чему равно 7²?", "opts": ["14", "49", "42", "56"], "answer": 1},
            ],
        },
        "ДЗ": {
            "name": "Проверка домашней работы по алгебре",
            "time_minutes": 15,
            "questions": [
                {"q": "Решите: 2x = 10", "opts": ["x = 2", "x = 5", "x = 8", "x = 10"], "answer": 1},
                {"q": "Разложите на множители: x² − 9", "opts": ["(x−3)(x+3)", "(x−9)(x+1)", "(x−3)²", "(x+9)(x−1)"], "answer": 0},
                {"q": "Чему равно 3! (3 факториал)?", "opts": ["3", "6", "9", "12"], "answer": 1},
            ],
        },
    },
    "Физика": {
        "Экзамен": {
            "name": "Итоговый экзамен по физике",
            "time_minutes": 30,
            "questions": [
                {"q": "Второй закон Ньютона?", "opts": ["F = ma", "E = mc²", "V = IR", "P = IV"], "answer": 0},
                {"q": "Единица электрического сопротивления?", "opts": ["Вольт", "Ампер", "Ом", "Ватт"], "answer": 2},
                {"q": "Скорость света ≈ ?", "opts": ["3×10⁶ м/с", "3×10⁸ м/с", "3×10⁵ м/с", "3×10¹⁰ м/с"], "answer": 1},
                {"q": "Какая частица имеет отрицательный заряд?", "opts": ["Протон", "Нейтрон", "Электрон", "Фотон"], "answer": 2},
                {"q": "Чему равен 1 Ньютон?", "opts": ["1 кг·м/с²", "1 кг·м/с", "1 кг²·м", "1 кг/м²"], "answer": 0},
                {"q": "Какой закон: каждое действие имеет равное и противоположное противодействие?", "opts": ["1-й закон", "2-й закон", "3-й закон", "Закон всемирного тяготения"], "answer": 2},
            ],
        },
        "Тест": {
            "name": "Короткий тест по физике",
            "time_minutes": 10,
            "questions": [
                {"q": "Ускорение свободного падения на Земле ≈ ?", "opts": ["9.8 м/с²", "10.2 м/с²", "8.5 м/с²", "11 м/с²"], "answer": 0},
                {"q": "Единица энергии?", "opts": ["Ньютон", "Паскаль", "Джоуль", "Герц"], "answer": 2},
                {"q": "Что измеряет вольтметр?", "opts": ["Ток", "Напряжение", "Сопротивление", "Мощность"], "answer": 1},
            ],
        },
    },
    "История": {
        "Экзамен": {
            "name": "Экзамен по всемирной истории",
            "time_minutes": 25,
            "questions": [
                {"q": "Когда закончилась Вторая мировая война?", "opts": ["1943", "1944", "1945", "1946"], "answer": 2},
                {"q": "Кто написал Декларацию независимости США?", "opts": ["Линкольн", "Джефферсон", "Вашингтон", "Адамс"], "answer": 1},
                {"q": "В каком году началась Французская революция?", "opts": ["1776", "1789", "1799", "1812"], "answer": 1},
                {"q": "Древний Египет располагался возле какой реки?", "opts": ["Амазонка", "Нил", "Дунай", "Ганг"], "answer": 1},
                {"q": "Эпоха Возрождения началась в какой стране?", "opts": ["Франция", "Англия", "Италия", "Испания"], "answer": 2},
            ],
        },
        "Тест": {
            "name": "Короткий тест по истории",
            "time_minutes": 10,
            "questions": [
                {"q": "Кто был первым президентом США?", "opts": ["Адамс", "Джефферсон", "Вашингтон", "Линкольн"], "answer": 2},
                {"q": "Холодная война велась между?", "opts": ["США и Великобританией", "США и СССР", "Великобританией и Францией", "Китаем и Японией"], "answer": 1},
                {"q": "В каком году пала Берлинская стена?", "opts": ["1987", "1988", "1989", "1991"], "answer": 2},
            ],
        },
    },
    "Информатика": {
        "Тест": {
            "name": "Короткий тест по информатике",
            "time_minutes": 10,
            "questions": [
                {"q": "Что означает аббревиатура CPU?", "opts": ["Central Processing Unit", "Computer Personal Unit", "Control Program Unit", "Central Processor Utility"], "answer": 0},
                {"q": "Что из перечисленного — язык программирования?", "opts": ["HTTP", "Python", "HTML", "JSON"], "answer": 1},
                {"q": "Двоичное 1010 соответствует какому десятичному числу?", "opts": ["8", "10", "12", "16"], "answer": 1},
                {"q": "Что означает RAM?", "opts": ["Read Access Memory", "Random Access Memory", "Run Active Memory", "Rapid Accessible Memory"], "answer": 1},
            ],
        },
        "ДЗ": {
            "name": "Проверка домашней работы по информатике",
            "time_minutes": 15,
            "questions": [
                {"q": "Что выведет print(2 + 2 * 3)?", "opts": ["12", "8", "10", "6"], "answer": 1},
                {"q": "С какого символа начинается комментарий в Python?", "opts": ["//", "#", "/*", "--"], "answer": 1},
                {"q": "Какой тип данных у значения 3.14?", "opts": ["int", "str", "float", "bool"], "answer": 2},
            ],
        },
        "Экзамен": {
            "name": "Итоговый экзамен по информатике",
            "time_minutes": 30,
            "available": False,
            "questions": [],
        },
    },
    "Английский": {
        "Экзамен": {
            "name": "Экзамен по английскому языку",
            "time_minutes": 25,
            "questions": [
                {"q": "Синоним слова 'eloquent'?", "opts": ["Silent", "Articulate", "Confused", "Loud"], "answer": 1},
                {"q": "Выберите грамматически верное предложение:", "opts": ["Him and I went.", "He and I went.", "Me and him went.", "I and he went."], "answer": 1},
                {"q": "'Metaphor' — это:", "opts": ["Сравнение со словом 'like'", "Прямое сравнение", "Преувеличение", "Звукоподражание"], "answer": 1},
                {"q": "Прошедшее время глагола 'swim'?", "opts": ["Swimmed", "Swam", "Swum", "Swimed"], "answer": 1},
                {"q": "Антоним слова 'benevolent'?", "opts": ["Kind", "Generous", "Malevolent", "Gentle"], "answer": 2},
            ],
        },
        "Тест": {
            "name": "Короткий тест по грамматике",
            "time_minutes": 10,
            "questions": [
                {"q": "Из 'their', 'there', 'they're' — которое показывает принадлежность?", "opts": ["there", "their", "they're", "Все вместе"], "answer": 1},
                {"q": "Какое из слов — существительное?", "opts": ["Quickly", "Beautiful", "Happiness", "Run"], "answer": 2},
                {"q": "Множественное число слова 'child'?", "opts": ["Childs", "Childes", "Children", "Childrens"], "answer": 2},
            ],
        },
    },
}

def hash_password(password):
    salt = secrets.token_hex(16)
    hashed = hashlib.sha256((salt + password).encode()).hexdigest()
    return f"{salt}:{hashed}"


def verify_password(stored, password):
    salt, hashed = stored.split(":")
    return hashlib.sha256((salt + password).encode()).hexdigest() == hashed


def load_users():
    conn = get_db()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute("SELECT username, password, full_name, email FROM users")
            return {row["username"]: row for row in cur.fetchall()}
    finally:
        conn.close()


def save_user(username, password_hash, full_name, email):
    conn = get_db()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO users (username, password, full_name, email) VALUES (%s, %s, %s, %s)",
                (username, password_hash, full_name, email),
            )
        conn.commit()
    finally:
        conn.close()


def get_user_csv_path(username):
    user_dir = os.path.join(USERS_DIR, username)
    os.makedirs(user_dir, exist_ok=True)
    return os.path.join(user_dir, "grades.csv")


def load_grades(username):
    path = get_user_csv_path(username)
    grades = []
    if os.path.exists(path):
        with open(path, "r") as f:
            lines = f.read().strip().split("\n")
        if len(lines) < 2:
            return grades
        header = lines[0].split(",")
        for line in lines[1:]:
            if not line.strip():
                continue
            values = line.split(",", len(header) - 1)
            row = dict(zip(header, values))
            row["score"] = int(row["score"]) if row.get("score") else None
            row["max_score"] = int(row["max_score"]) if row.get("max_score") else None
            if row["score"] is not None and row["max_score"]:
                row["percentage"] = round((row["score"] / row["max_score"]) * 100, 1)
            else:
                row["percentage"] = None
            row["homework"] = row.get("homework", "") or ""
            row["exam"] = row.get("exam", "0") == "1"
            grades.append(row)
    return grades


def save_grade(username, subject, score, max_score, homework="", is_exam=False):
    path = get_user_csv_path(username)
    new_file = not os.path.exists(path) or os.path.getsize(path) == 0
    date = datetime.now().strftime("%Y-%m-%d %H:%M")
    homework_safe = homework.replace('"', '""')
    score_str = str(score) if score is not None else ""
    max_score_str = str(max_score) if max_score else ""
    exam_flag = "1" if is_exam else "0"
    with open(path, "a") as f:
        if new_file:
            f.write(",".join(GRADES_HEADER) + "\n")
        f.write(f"{date},{subject},{exam_flag},{score_str},{max_score_str},{homework_safe}\n")
    return round((score / max_score) * 100, 1) if score is not None and max_score else None


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "username" not in session:
            flash("Пожалуйста, войдите в аккаунт.", "warning")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated


def get_letter_grade(pct):
    if pct is None:
        return "—"
    if pct >= 100: return "5"
    if pct >= 80: return "4"
    if pct >= 50: return "3"
    if pct >= 30: return "2"
    return "1"


@app.route("/")
def index():
    if "username" in session:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "").strip()
        confirm = request.form.get("confirm", "").strip()
        full_name = request.form.get("full_name", "").strip()
        email = request.form.get("email", "").strip()

        if not all([username, password, full_name, email]):
            flash("Все поля обязательны для заполнения.", "error")
            return redirect(url_for("register"))
        if len(username) < 6:
            flash("Логин должен содержать минимум 6 символов.", "error")
            return redirect(url_for("register"))
        if "/" in username or "\\" in username or ".." in username:
            flash("Логин содержит недопустимые символы.", "error")
            return redirect(url_for("register"))
        if len(password) < 9:
            flash("Пароль должен содержать минимум 9 символов.", "error")
            return redirect(url_for("register"))
        if password == username:
            flash("Пароль не должен совпадать с именем.", "error")
            return redirect(url_for("register"))
        if password != confirm:
            flash("Пароли не совпадают.", "error")
            return redirect(url_for("register"))

        users = load_users()
        if username in users:
            flash("Такой логин уже занят.", "error")
            return redirect(url_for("register"))

        save_user(username, hash_password(password), full_name, email)
        get_user_csv_path(username)

        flash("Регистрация успешна! Теперь войдите в аккаунт.", "success")
        return redirect(url_for("login"))

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "").strip()

        users = load_users()
        if username not in users or not verify_password(users[username]["password"], password):
            flash("Неверный логин или пароль.", "error")
            return redirect(url_for("login"))

        session["username"] = username
        session["full_name"] = users[username]["full_name"]
        flash(f"С возвращением, {users[username]['full_name']}!", "success")
        return redirect(url_for("dashboard"))

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("Вы вышли из аккаунта.", "info")
    return redirect(url_for("login"))


@app.route("/dashboard")
@login_required
def dashboard():
    grades = load_grades(session["username"])
    graded = [g for g in grades if g["percentage"] is not None]

    subjects = {}
    for g in graded:
        subj = g["subject"]
        if subj not in subjects:
            subjects[subj] = {"scores": [], "count": 0}
        subjects[subj]["scores"].append(g["percentage"])
        subjects[subj]["count"] += 1

    summary = {}
    for subj, data in subjects.items():
        avg = round(sum(data["scores"]) / len(data["scores"]), 1)
        summary[subj] = {
            "average": avg,
            "count": data["count"],
            "grade": get_letter_grade(avg),
        }

    all_sorted = sorted(grades, key=lambda x: x["date"], reverse=True)
    recent_grades = [g for g in all_sorted if g["score"] is not None][:5]
    recent_homework = [g for g in all_sorted if g["score"] is None and g["homework"]][:5]

    finals = []
    flag = ""
    available_perfect_count = 0
    available_total = 0
    for subj, types in TEST_BANK.items():
        exam = types.get("Экзамен")
        if not exam:
            continue
        is_available = exam.get("available", True)
        best_pct = None
        exam_rows = [g for g in graded if g["subject"] == subj and g.get("exam")]
        if exam_rows:
            best_pct = max(g["percentage"] for g in exam_rows)
        finals.append({
            "subject": subj,
            "name": exam["name"],
            "available": is_available,
            "percentage": best_pct,
            "grade": get_letter_grade(best_pct),
            "taken": best_pct is not None,
        })
        available_total += 1
        if best_pct == 100.0:
            available_perfect_count += 1

    all_perfect = available_total > 0 and available_perfect_count == available_total
    if all_perfect:
        flag = "alfa{XXXXXXXXX_REDACTED_XXXXXXXXX}"
    else:
        flag = "asdf"

    return render_template(
        "dashboard.html",
        summary=summary,
        recent_grades=recent_grades,
        recent_homework=recent_homework,
        get_letter_grade=get_letter_grade,
        finals=finals,
        all_perfect=all_perfect,
        flag=flag
    )


@app.route("/tests")
@login_required
def tests():
    return render_template("tests.html", test_bank=TEST_BANK)


@app.route("/test/<subject>/<test_type>", methods=["GET", "POST"])
@login_required
def take_test(subject, test_type):
    if subject not in TEST_BANK or test_type not in TEST_BANK[subject]:
        abort(404)

    test = TEST_BANK[subject][test_type]

    if not test.get("available", True):
        flash(f"Тест «{test['name']}» пока недоступен.", "warning")
        return redirect(url_for("tests"))

    if request.method == "POST":
        score = 0
        total = len(test["questions"])
        details = []
        for i, question in enumerate(test["questions"]):
            user_answer = request.form.get(f"q{i}")
            correct = question["answer"]
            is_correct = user_answer is not None and int(user_answer) == correct
            if is_correct:
                score += 1
            details.append({
                "question": question["q"],
                "user_answer": question["opts"][int(user_answer)] if user_answer is not None else "Нет ответа",
                "correct_answer": question["opts"][correct],
                "is_correct": is_correct,
            })

        percentage = save_grade(session["username"], subject, score, total, is_exam=(test_type == "Экзамен"))

        return render_template(
            "result.html",
            test=test,
            subject=subject,
            test_type=test_type,
            score=score,
            total=total,
            percentage=percentage,
            grade=get_letter_grade(percentage),
            details=details,
        )

    return render_template("take_test.html", test=test, subject=subject, test_type=test_type)


@app.route("/learner")
@login_required
def learner():
    grades = load_grades(session["username"])
    grades_sorted = sorted(grades, key=lambda x: x["date"], reverse=True)

    subject_summary = {}
    for g in grades_sorted:
        subj = g["subject"]
        if subj not in subject_summary:
            subject_summary[subj] = {"count": 0, "scores": []}
        subject_summary[subj]["count"] += 1
        if g["percentage"] is not None:
            subject_summary[subj]["scores"].append(g["percentage"])
    for subj, data in subject_summary.items():
        if data["scores"]:
            data["average"] = round(sum(data["scores"]) / len(data["scores"]), 1)
            data["grade"] = get_letter_grade(data["average"])
        else:
            data["average"] = None
            data["grade"] = "—"

    filter_subject = request.args.get("subject", "all")

    filtered = grades_sorted
    if filter_subject != "all":
        filtered = [g for g in filtered if g["subject"] == filter_subject]

    all_subjects = sorted(set(g["subject"] for g in grades))

    test_grades = [g for g in filtered if g["score"] is not None]
    homework_list = [g for g in filtered if g["score"] is None and g["homework"]]

    return render_template(
        "learner.html",
        test_grades=test_grades,
        homework_list=homework_list,
        subjects=sorted(TEST_BANK.keys()),
        all_subjects=all_subjects,
        filter_subject=filter_subject,
        get_letter_grade=get_letter_grade,
    )


@app.route("/homework", methods=["POST"])
@login_required
def add_grade():
    subject = request.form.get("subject", "").strip()
    homework = request.form.get("homework", "").strip()

    if not subject:
        flash("Пожалуйста, выберите предмет.", "error")
        return redirect(url_for("learner"))
    if not homework:
        flash("Пожалуйста, опишите домашнее задание.", "error")
        return redirect(url_for("learner"))

    save_grade(session["username"], subject, None, None, homework=homework)
    flash("Домашнее задание добавлено в журнал.", "success")
    return redirect(url_for("learner"))


@app.route("/csv")
@login_required
def download_csv():
    path = get_user_csv_path(session["username"])
    if os.path.exists(path):
        with open(path, "r") as f:
            content = f.read()
    else:
        content = ",".join(GRADES_HEADER)

    return Response(
        content,
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment;filename={session['username']}_grades.csv"},
    )

if __name__ == "__main__":
    app.run(debug=False, host="0.0.0.0", port=8080)
